# Logical Fallacies and Context Manipulation Checklist

Use this checklist during verification to detect subtle deception, faulty reasoning, and context distortions.

## 1. Context Stripping & Quoting Fallacies
- **Quote Mining**: Extracting a quote out of context to make the speaker appear to endorse a position they actually argued against.
- **Temporal Distortion (Zombie Claims)**: Presenting authentic news footage or photographs from years ago as if they occurred today.
- **Geographic Misattribution**: Attaching real footage of a crisis in Country A to an unfolding event in Country B.

## 2. Statistical & Numerical Fallacies
- **Base Rate Fallacy / Absolute vs. Relative Risk**: Highlighting a "50% increase in risk" when the absolute risk only rose from 2 in 100,000 to 3 in 100,000.
- **Truncated / Misleading Axes**: Graphing data with an truncated Y-axis to make modest fluctuations look like catastrophic surges or collapses.
- **Cherry-Picked Timeframes**: Selecting non-representative starting or ending dates to manufacture a false trend (e.g. measuring inflation from an anomalous single-month peak).
- **Survivorship Bias**: Drawing conclusions based exclusively on entities that passed a selection process while ignoring those that failed.
- **Ecological Fallacy**: Inappropriately applying aggregate population-level statistics to individual persons or subgroups.

## 3. Causal & Reasoning Fallacies
- **Post Hoc Ergo Propter Hoc**: Assuming that because Event B followed Event A, Event A must have caused Event B.
- **Confusing Correlation with Causation**: Asserting a direct causal mechanism between two variables that merely share a common underlying trend.
- **False Equivalence**: Equating two fundamentally unequal situations as though they carry identical moral, legal, or statistical weight.
- **False Dilemma**: Presenting only two extreme choices when viable moderate alternatives exist.
- **Appeal to False Authority**: Citing an expert in one discipline (e.g. quantum physics) to endorse claims in an unrelated field (e.g. viral epidemiology).

## 4. Synthetic Media & AI Indicators
- **Deepfake / Generative Artifacts**: Inconsistencies in anatomical geometry, unnatural blinking, mismatched lighting shadows, audio cadence anomalies.
- **Cheapfakes / Shallowfakes**: Simple speed alterations (slowing down video to make someone sound intoxicated), selective cropping, or altered pitch.
- **Provenance Verification**: Check for reverse image search matches, EXIF metadata, watermarks, and cryptographic C2PA content credentials.
