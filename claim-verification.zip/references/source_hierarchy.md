# Evidence Hierarchy and Source Evaluation Guide

A structured guide for categorizing, weighting, and cross-examining sources during claim verification.

## Source Reliability Tiers

### Tier 1: Primary and Authoritative Sources
- **Description**: First-hand, unaltered empirical records, legal filings, statutory datasets, and rigorous peer-reviewed scientific studies.
- **Examples**:
  - Official government statistical bureaus (e.g. ABS, BLS, ONS).
  - Certified court documents, legislative transcripts, and official gazettes.
  - Raw sensor data, financial filings (e.g. SEC 10-K, ASX announcements).
  - Preregistered, double-blind peer-reviewed scientific papers in reputable journals.
  - Uncut, verified video or audio recordings with verifiable cryptographic or camera metadata.

### Tier 2: Established Secondary Journalism & Wire Agencies
- **Description**: Reputable news agencies with rigorous editorial oversight, transparent correction policies, and dedicated fact-checking units.
- **Examples**:
  - Global wire services (Reuters, Associated Press, AFP).
  - Established national public broadcasters and investigative news organizations (e.g. ABC News Australia, BBC, The Guardian, NPR).
  - IFCN-certified fact-checking organizations (e.g. RMIT ABC Fact Check, PolitiFact, Snopes, Full Fact).

### Tier 3: Domain Expert Commentary & Institutional Reports
- **Description**: Analysis and synthesis by recognized industry experts, reputable academic institutes, and independent non-partisan think tanks.
- **Examples**:
  - University policy center working papers.
  - Specialized industry regulatory whitepapers.
  - Technical analysis published by recognized professional associations (e.g. IEEE, AMA, Engineers Australia).

### Tier 4: Self-Published & Low-Corroboration Sources
- **Description**: Platforms lacking professional editorial oversight, blind peer review, or formal correction mechanisms.
- **Examples**:
  - Personal blogs, Substack posts without primary citations.
  - Partisan political advocacy releases and lobbyist memos.
  - Social media posts by non-verified or unauthenticated individuals.
  - Anonymous insider tips and leaks without secondary document verification.

### Tier 5: Disqualified / High-Risk Sources
- **Description**: Known purveyors of fabricated content, deceptive networks, state-controlled propaganda, or unvetted synthetic media.
- **Treatment**: Cannot be used as evidence of fact. Can only be cited as evidence that a specific false narrative exists.

---

## SIFT Lateral Reading Protocol

1. **Stop**: Pause when encountering an alarming, surprising, or highly emotionally charged claim. Check immediate emotional reactions.
2. **Investigate the Source**: Determine who is publishing or promoting the claim. Check funding, mission, domain registration history, and editorial track record.
3. **Find Better Coverage**: Look beyond the initial reporting. Search whether trusted wire services or specialized institutions have independently corroborated the story.
4. **Trace Claims to the Original Context**: Follow citations back to the raw source document, unedited interview, or primary dataset to inspect original phrasing and methodology.
