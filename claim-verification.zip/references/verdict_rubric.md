# Verification Verdict Rubric

A standardized classification framework for assigning objective, consistent fact-checking verdicts.

## Verdict Categories

### 1. True
- **Definition**: The claim is fully accurate in all material facts with no significant omissions, distortion, or misleading context.
- **Criteria**: Backed by verified Tier 1 primary sources, official public records, or unambiguous empirical consensus.
- **Example**: "Australia has 6 states and 2 major mainland territories."

### 2. Mostly True
- **Definition**: The primary substance of the claim is accurate, but it contains minor technical inaccuracies, slight exaggerations, or trivial omissions that do not alter the fundamental conclusion.
- **Criteria**: Core factual assertions are corroborated; minor peripheral details may lack precision.
- **Example**: "State X built 50 new schools this year" (when official records confirm 48 opened and 2 were renovated).

### 3. Half True / Nuanced
- **Definition**: The claim contains elements of truth, but leaves out critical context, blends accurate facts with inaccurate interpretations, or requires substantial qualification to be properly understood.
- **Criteria**: Factual premise is partially correct, but key qualifying factors change the overall picture.
- **Example**: "Violent crime rose by 25% last year" (accurate for one specific municipality, but national violent crime dropped by 5%).

### 4. Mostly False
- **Definition**: The claim contains an element of truth or references a real event, but distorts or misinterprets key facts to the extent that it conveys a fundamentally false impression.
- **Criteria**: The main assertion is refuted by evidence, even if a tangential detail is accurate.
- **Example**: "The government banned gas stoves nationwide" (when an advisory panel only proposed emissions guidelines for new commercial buildings).

### 5. False
- **Definition**: The claim is factually inaccurate, fabricated, or thoroughly contradicted by verified empirical records and credible evidence.
- **Criteria**: No factual basis found, or direct primary evidence disproves the assertion completely.
- **Example**: "The moon landing was filmed on a Hollywood stage in 1968."

### 6. Misleading / Missing Context
- **Definition**: The claim uses authentic data, real quotes, or genuine media, but frames, edits, or isolates them in a manner that creates an intentionally or accidentally deceptive conclusion.
- **Criteria**: Literal words or images are real, but their selective presentation creates a falsehood.
- **Example**: Showing footage of an earthquake drill and claiming it depicts an active disaster.

### 7. Unproven / Insufficient Evidence
- **Definition**: There is currently not enough publicly available, verifiable evidence or reliable data to confirm or refute the claim.
- **Criteria**: Sources are anonymous, investigations are ongoing, or proprietary datasets are inaccessible.
- **Example**: "Company X will merge with Company Y next quarter" (based on anonymous unverified rumors).

### 8. Unverifiable / Opinion
- **Definition**: The statement is non-falsifiable, purely subjective, speculative about future outcomes, or based on philosophical, religious, or aesthetic values.
- **Criteria**: Cannot be resolved through empirical inquiry or fact-checking methods.
- **Example**: "Action movie X is the greatest cinematic achievement of the decade."

---

## Confidence Rating Scale

- **High Confidence**: Supported by multiple independent Tier 1 primary sources, verifiable datasets, or established empirical consensus. Minimal uncertainty.
- **Moderate Confidence**: Supported by credible Tier 2 secondary reporting and consistent circumstantial evidence, but direct raw primary data is limited or unavailable.
- **Low Confidence**: Relying on single-source reports, conflicting accounts, or partial data. High likelihood of revisions as new information emerges.
- **Insufficient**: Available data is too sparse or contradictory to establish credibility.
