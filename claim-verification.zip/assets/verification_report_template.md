# Claims Verification Report Template

```markdown
# Claims Verification Report: [Short Title / Subject of Claim]

**Submitted Claim**: "[Full exact text of the claim being investigated]"
**Claimant / Source**: [Name of speaker, publication, platform, or account]
**Date of Origin**: [YYYY-MM-DD or timeframe]
**Overall Verdict**: **[ VERDICT: True / Mostly True / Half True / Mostly False / False / Misleading / Unproven ]**
**Confidence Rating**: **[ High / Moderate / Low / Insufficient ]**

---

## Executive Summary

- [2-3 sentence overview explaining why this verdict was reached.]
- [Highlight the single most decisive piece of evidence.]
- [Note any critical context, caveats, or nuances the reader should know.]

---

## Atomic Claim Decomposition & Findings

| # | Sub-Claim / Proposition | Classification | Specific Verdict | Key Primary Evidence |
|---|---|---|---|---|
| 1 | [Atomic statement 1] | Empirical Metric | Verified True | [Source Title](URL) |
| 2 | [Atomic statement 2] | Attribution / Quote | Misleading | [Official Transcript](URL) |
| 3 | [Atomic statement 3] | Causal Assertion | False | [Research Study](URL) |

---

## Detailed Evidence & Analysis

### Sub-Claim 1: [Statement 1]
- **Analysis**: [Detailed examination of data, documents, or context.]
- **Supporting Evidence**: [Primary records, datasets, or quotes with links.]
- **Counter-Evidence / Rebuttal**: [Contradictory data or explanations considered.]

### Sub-Claim 2: [Statement 2]
- **Analysis**: [Detailed examination of data, documents, or context.]
- **Supporting Evidence**: [Primary records, datasets, or quotes with links.]
- **Counter-Evidence / Rebuttal**: [Contradictory data or explanations considered.]

---

## Context, Fallacies & Missing Nuance

- **Omitted Context**: [What essential background was left out of the original claim?]
- **Fallacies Detected**: [Note any cherry-picking, temporal distortion, false correlation, etc.]
- **Stakeholder / Expert Responses**: [Relevant statements from subjects of the claim or domain specialists.]

---

## Evidence Sources & Citations

1. [Tier 1] [Source Organization / Author - Document Title](https://example.com/source1) - Official dataset / primary filing.
2. [Tier 2] [News Organization - Article Title](https://example.com/source2) - Verified journalistic reporting.
3. [Tier 1] [Government Department - Official Release](https://example.com/source3) - Regulatory statement.

---

## Verification Methodology Note

- **Search Parameters & Scope**: [Date range, keywords, repositories queried.]
- **Limitations**: [Any inaccessible data, ongoing investigations, or unresolved discrepancies.]
```
