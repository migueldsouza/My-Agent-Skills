---
name: claim-verification
description: Apply rigorous fact-checking, claims checking, and intelligence verification methodologies to analyze any submitted claim, statement, rumor, quote, or dataset. Deconstructs claims into atomic verifiable assertions, conducts multi-source lateral reading, evaluates primary evidence, detects logical fallacies and context distortion, and produces structured verification verdicts with confidence ratings. Use when the user asks to verify a claim, check facts, debunk or confirm a rumor, audit a statement, investigate misinformation, or assess the accuracy and evidence behind any assertion.
allowed-tools: google youtube docs_agent drive context_service_agent
---
# Claim Verification

A professional-grade verification and fact-checking skill designed to scrutinize assertions, analyze supporting and contradicting evidence, detect deceptive framing, and deliver transparent, evidence-backed verdicts.

## When to Use

- When a user asks to verify a factual statement, news headline, public quote, statistical assertion, or historical claim.
- When investigating viral social media posts, alleged leaks, rumors, conspiracy theories, or potential misinformation/disinformation.
- When auditing policy documents, political speeches, press releases, corporate PR claims, or scientific summaries.
- When performing source provenance checks, tracing data to primary repositories, or evaluating context manipulation.
- When asked to provide a structured fact-check report, verification matrix, or confidence rating for complex multi-part claims.

## Core Workflow

### 1. Ingest and Deconstruct Claims

Break down the user query or submitted text into distinct, atomic factual propositions:

- **Extract Atomic Assertions**: Separate compound sentences into standalone, falsifiable assertions. A single statement often contains multiple independent claims (e.g. "Entity X increased budget Y by Z% in year W").
- **Identify Core Entities and Metrics**: Highlight key actors, dates, numerical values, geographic locations, legal statutes, and specific terminology.
- **Distinguish Facts from Values**: Separate verifiable empirical assertions (e.g. "Unemployment fell to 3.8%") from subjective commentary, opinions, or normative judgments (e.g. "The economic policy was a disaster").
- **Document the Initial Context**: Record who made the claim, where, when, in what medium, and to what target audience.

### 2. Formulate Investigative Queries and Lateral Reading

Do not evaluate a claim solely by reading the source that made it. Practice lateral reading across multiple independent sources:

- **Primary Source Tracing**: Trace the assertion back to the original origin (statutory data, official transcripts, court filings, peer-reviewed papers, unedited video/audio).
- **Search Formulation**: Conduct targeted searches using neutral keyword combinations, specific data series identifiers, named witnesses, and Boolean queries.
- **Lateral Source Vetting**: Open search tabs across independent domain authorities, fact-checking archives, regulatory bodies, and academic repositories to assess the credibility and biases of the originating source.
- **Check for Circular Reporting**: Ensure that multiple outlets reporting the same claim are not merely quoting each other or relying on a single unverified wire brief.

### 3. Source Hierarchy and Evidence Grading

Evaluate all gathered evidence according to strict hierarchy standards (see `references/source_hierarchy.md`):

- **Tier 1 (Primary / Authoritative)**: Official government data, verified registry entries, raw sensor/filing data, court exhibits, preregistered scientific studies.
- **Tier 2 (Reputable Secondary / Wire Services)**: Direct reporting by verified wire agencies (Reuters, AP) and established investigative journalism with clear editorial correction policies.
- **Tier 3 (Contextual / Expert Analysis)**: Independent peer analysis, specialized domain think tanks, academic reviews.
- **Tier 4 (Low Reliability / Uncorroborated)**: Anonymous social accounts, partisan blogs, press releases without empirical attachments.
- **Resolve Data Conflicts**: Give precedence to primary empirical records over secondary interpretations. When reputable sources disagree, present the exact nature of the disagreement rather than forcing a false consensus.

### 4. Scrutinize Context, Omissions, and Manipulation

Verify not only whether the literal words are true, but whether the overall impression conveyed is accurate (see `references/fallacy_and_bias_checklist.md`):

- **Temporal Accuracy**: Check if an authentic historical event is being falsely presented as current breaking news.
- **Context Stripping (Quote Mining)**: Verify full context of quotations. Determine if omitted preceding or following sentences alter the speaker intent.
- **Statistical Manipulation**: Inspect baselines, sample sizes, absolute vs relative risk changes, adjusted vs nominal figures, and truncated graph axes.
- **Visual / Media Integrity**: For claims involving images or video, check whether media has been cropped, edited, generated via AI, or repurposed from an unrelated event.
- **Causal Leaps**: Identify post hoc ergo propter hoc fallacies, confusing correlation with causation, or attributing broad macroeconomic trends to a single isolated policy.

### 5. Assign Standardized Verdict and Confidence

Assign a definitive verdict using the standardized rubric (see `references/verdict_rubric.md`):

- **True**: Accurate in all material facts; supported by verified primary evidence.
- **Mostly True**: Accurate on core substance, but contains minor inaccuracies or non-material omissions.
- **Half True / Nuanced**: Partially accurate, but omits critical context or combines accurate facts with unsubstantiated conclusions.
- **Mostly False**: Contains an element of truth, but distorts central facts or presents a fundamentally misleading narrative.
- **False**: Inaccurate, fabricated, or directly refuted by established evidence.
- **Misleading / Missing Context**: Uses authentic facts or quotes in a deceitful, stripped-of-context, or manipulative manner.
- **Unproven / Insufficient Evidence**: Insufficient public or verifiable data exists to confirm or refute the claim at this time.
- **Unverifiable**: Inherently unfalsifiable, purely subjective, or speculative.
- **Assign Confidence Level**: Explicitly rate confidence as High, Moderate, or Low based on evidence availability and source convergence.

### 6. Generate the Structured Verification Report

Produce a clean, objective report following the template in `assets/verification_report_template.md`. When creating a Google Doc or responding in chat:

- **Executive Verdict Box**: State the claim, verdict badge, and a 2-3 sentence verdict rationale.
- **Deconstructed Sub-Claims Table**: Detail each component proposition, its specific verdict, and primary evidence source.
- **Evidence Matrix**: Provide direct clickable markdown links [Source Title](URL) for every cited source.
- **Context, Caveats, and Nuance**: Detail missing background, historical comparisons, and technical qualifications.
- **Methodology & Transparency Note**: Explain search bounds, dates examined, and any limitations encountered.

## Gotchas and Best Practices

- **Never treat assertion as evidence**: A statement repeated by multiple blogs remains unverified if they all trace back to one unsourced tweet.
- **Avoid false balance**: Do not give equal weight to fringe or debunked claims when an overwhelming scientific or empirical consensus exists.
- **Always preserve attribution**: Clearly distinguish between what is an established fact and what is an official allegation or partisan statement.
- **Use clickable markdown hyperlinks**: Every single evidence point must link directly to the source URL retrieved from tool calls.
- **Handle breaking / developing news with care**: Early reports of dynamic events often contain conflicting information; label emerging facts as "Developing / Uncorroborated" until official confirmation is obtained.
- **Check dates and definitions**: Subtle definition changes (e.g. how unemployment or inflation is calculated across jurisdictions) frequently create misleading claims.
