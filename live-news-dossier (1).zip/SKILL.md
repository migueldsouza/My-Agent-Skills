---
name: live-news-dossier
description: Research, verify, and build an updating news dossier document for breaking and evolving news stories from any seed input (text snippet, map link, dataset, or query). Use when the user asks to track a breaking story, build a live news briefing, verify news leads, gather multimedia/sources, or maintain an updating Google Doc for developing news events.
allowed-tools: google youtube docs_agent drive google_maps_tool
---
# Live News Dossier

A specialized newsroom research and verification skill for journalists, editors, and researchers to track evolving stories and maintain a living Google Doc dossier with verified reporting, multimedia, geolocation data, and real-time updates.

## When to Use

- When tracking breaking or developing news stories across local, national, or international outlets.
- When given a raw lead, such as a snippet of text, a social media post, a map coordinate/link, a data sample, or a broad question about an ongoing event.
- When creating or updating a structured news dossier in Google Docs with verified sources, video footage, image links, maps, and timeline events.
- When corroborating unconfirmed reports across multiple reputable primary and secondary news sources.

## Core Workflow

### 1. Ingest and Deconstruct Seed Input

Analyze the initial user input to determine the story angle, entities involved, and verification priorities:

- **Text Snippets / Social Posts**: Identify core claims, named entities (people, organizations, locations), and alleged timeframes.
- **Map Links / Coordinates**: Extract geographic context, nearby landmarks, administrative jurisdictions, and local news outlets relevant to that area.
- **Data Samples / Statistics**: Identify baseline figures, trends, anomalies, and the primary source or publisher of the data.
- **Research Questions / Prompts**: Formulate distinct sub-questions for background context, timeline of events, key stakeholders, and latest updates.

### 2. Multi-Source Fact Gathering and Verification

Conduct thorough multi-source research to establish ground truth:

- Search for primary sources (government releases, emergency services, official statements, court records).
- Cross-reference multiple established wire services and credible news publishers (e.g., Reuters, AP, BBC, ABC Australia, The Guardian, local papers).
- Check timestamps on conflicting reports to distinguish earlier misreporting from newer verified developments.
- Label claims with explicit confidence levels: Confirmed, Developing / Reported by [Source], or Unverified / Contested.

### 3. Locate Multimedia, Geolocation, and Contextual Assets

Enrich the story with relevant media and data context:

- **Video Content**: Search for verified press conferences, on-the-ground news broadcasts, eyewitness footage, or explanatory reporting on YouTube.
- **Imagery & Maps**: Gather reference links for satellite imagery, route maps, infographics, and verified news photographs.
- **Data & Background**: Collate relevant historical statistics, demographic figures, or comparative datasets.

### 4. Create or Update the Google Doc Dossier

Structure the news dossier clearly in a Google Doc to serve as a single source of truth:

- **Headline & Story Slug**: Clear, objective title reflecting current status.
- **Executive Summary / Key Takeaways**: 3 to 4 bullet points summarizing verified facts.
- **Live Timeline**: Chronological log of developments with date and time tags.
- **Deep-Dive Reporting & Analysis**: Detailed breakdown of key facets, quotes, and stakeholder responses.
- **Verified Sources & Citations**: Direct markdown hyperlinks to all referenced articles, releases, and reports.
- **Multimedia & Supporting Assets**: Curated links to video clips, maps, and photographic evidence.
- **Developing Questions / Watchlist**: Open unknowns to monitor in subsequent updates.

### 5. Incremental Updates for Developing Stories

When new information arrives for an existing story:

- Read the existing document structure using Drive or Docs tools.
- Append new timeline entries with fresh timestamps.
- Update the Executive Summary if status or critical facts changed.
- Add newly verified sources without removing historical context.

## Gotchas and Best Practices

- **Never rely on a single unverified source**: Always require two or more independent corroborations for breaking claims.
- **Preserve attribution**: Always clearly attribute claims to the specific agency, journalist, or witness who reported them.
- **Use clean markdown links**: Every factual claim must link directly to the source URL.
- **Handle conflicting reports cleanly**: State the discrepancy clearly (e.g., "Source A reports X, while Source B states Y as of 14:00").
- **Maintain objective tone**: Avoid sensationalist framing or editorial speculation.
