---
name: council-story-miner
description: Meticulously analyzes local council meeting recordings, YouTube transcripts, official minutes, and agendas to identify high-value news story leads for Australian subscription newsrooms. Evaluates content against the User Needs framework (Help Me, Move Me, Challenge Me, Update Me), heavily prioritizing direct financial impacts, systemic service failures, and high-consequence community conflicts. Use when the user asks to analyze council meetings, monitor local government transcripts, extract story angles from council agendas or minutes, or run the newsroom council story miner.
allowed-tools: youtube google drive docs_agent gmail
---

# Council Story Miner

## Summary
Analyzes local council meeting recordings, transcripts, official minutes, and business papers to extract high-value story leads for Australian newsrooms using the strategic User Needs framework.

## When to Use
- When monitoring or evaluating local council meeting audio, video, or transcripts (e.g. YouTube webcasts).
- When ingesting official council agendas, business papers, or draft/confirmed meeting minutes.
- When generating structured story pitch cards, updating newsroom dossiers, or alerting beat reporters to council decisions.

## Editorial Strategy & Evaluation Filters

### 1. Primary Filters (High Priority)
- Direct Financial Consequence (Help Me): Top priority. Any discussion affecting reader finances: rate pegging, special rate variations (SRVs), fee increases, project cost blowouts, unexpected deficits, asset sales, borrowing, or procurement tenders.
- Systemic Problems & Reader Advocacy (Help Me / Move Me): Personal, emotional presentations or public questions illustrating wider bureaucratic failures, service delays, or unfair policies affecting many residents.
- High-Consequence Conflict (Challenge Me / Help Me): Non-unanimous votes, floor amendments, heated debates, and councillor dissents tied to a tangible outcome for the community.

### 2. Secondary Filters (Strictly Ignore)
- Purely procedural items (apologies, confirming prior minutes, noting correspondence, committee appointments).
- Minor, uncontroversial announcements accepted en bloc without debate.
- Political bickering or points of order with no policy or community consequence.

## Workflow Steps

1. Ingest Source Material:
   - For YouTube-hosted councils: retrieve video transcript and metadata using YouTube tools.
   - For proprietary webcast councils: retrieve newly published official agendas (published 3-5 days before meetings) or draft minutes (published shortly after).
2. Apply User Needs Evaluation:
   - Scan for the primary filter criteria.
   - Match each promising lead to its primary User Need: Help Me, Move Me, Challenge Me, or Update Me.
   - Extract exact figures, dates, voting splits, and key people.
   - Extract a single impactful verbatim "Power Quote" with exact timestamp (HH:MM:SS) or document reference.
3. Format Output:
   Structure every lead strictly according to the required newsroom schema:
   - Story Lead Headline
   - Primary User Need(s)
   - Summary of Key Information (Core issue, Key people, Specific figures/dates)
   - The Power Quote (with speaker and timestamp / document reference)
   - Strategic Value Assessment (one sentence on subscriber value)
   - Reporter Action Plan (2-3 concrete follow-up steps)
4. Publish and Alert:
   - Append new story leads to the council's master Google Doc dossier.
   - Format an alert email to the beat reporter with the lead pitch, Power Quote, and document link.

## Gotchas & Quality Standards
- Clean Typography: Never leave raw HTML entities (like &apos; or &quot;). Always sanitize into standard quotation marks and apostrophes.
- Grounding: Every quote must be verbatim from the transcript or minutes. Do not paraphrase inside quotation marks.
- Accuracy: Verify named divisions and vote tallies against written records.
